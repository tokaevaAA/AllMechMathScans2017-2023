#include "quant1/quant1.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    collar(const Data::CashFlow &rCap, double dFloorRate,
           InterestRateModel &rModel)
{
  PRECONDITION(dFloorRate < rCap.rate);
  
  std::vector<double> uEventTimes(rCap.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rCap](double dX) { return dX + rCap.period; });
  rModel.assignEventTimes(uEventTimes);

  //last minus one payment time
  int iTime = uEventTimes.size() - 1;
  double dCapFactor = 1. + rCap.rate * rCap.period;
  double dFloorFactor = 1. + dFloorRate * rCap.period;
  Slice uDiscount =
      rModel.discount(iTime, rModel.eventTimes()[iTime] + rCap.period);
  //value of cap payment at the next payment time
  Slice uCap = max(1. - uDiscount * dCapFactor, 0.);
  //value of floor payment at the next payment time
  Slice uFloor = max(uDiscount * dFloorFactor - 1., 0.);
  //we multiply on notional at the end
  Slice uOption = uCap - uFloor;

  while (iTime > 0)
  {
    //uOption is the value of future payments
    iTime--;
    uOption.rollback(iTime);
    uDiscount =
        rModel.discount(iTime, rModel.eventTimes()[iTime] + rCap.period);
    uCap = max(1. - uDiscount * dCapFactor, 0.);
    uFloor = max(uDiscount * dFloorFactor - 1., 0.);
    uOption += (uCap - uFloor);
  }
  uOption *= rCap.notional;

  return interpolate(uOption);
}
