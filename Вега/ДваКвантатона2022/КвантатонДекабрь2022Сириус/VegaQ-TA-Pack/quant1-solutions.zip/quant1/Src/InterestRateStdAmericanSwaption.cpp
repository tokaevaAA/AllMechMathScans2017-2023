#include "quant1/quant1.hpp"

using namespace cfl;
using namespace std;

namespace NAmerSwaption
{
  cfl::Slice
  couponBond(unsigned iTime, const Data::CashFlow &rBond,
             const InterestRateModel &rModel)
  {
    Slice uCashFlow = rModel.cash(iTime, 0.);
    double dTime = rModel.eventTimes()[iTime];
    for (unsigned iI = 0; iI < rBond.numberOfPayments; iI++)
    {
      dTime += rBond.period;
      uCashFlow += rModel.discount(iTime, dTime);
    }
    uCashFlow *= (rBond.rate * rBond.period);
    uCashFlow += rModel.discount(iTime, dTime);
    uCashFlow *= rBond.notional;
    return uCashFlow;
  }

  cfl::Slice swap(unsigned iTime, const Data::Swap &rSwap,
                  const InterestRateModel &rModel)
  {
    //assume first that we receive fixed and pay float
    Slice uSwap = couponBond(iTime, rSwap, rModel) - rSwap.notional;
    if (!rSwap.payFloat)
    { //if we pay fixed
      uSwap *= -1;
    }
    return uSwap;
  }
}

using namespace NAmerSwaption;

cfl::MultiFunction prb::
    americanSwaption(const Data::Swap &rSwap,
                     const std::vector<double> &rExerciseTimes,
                     InterestRateModel &rModel)
{
  PRECONDITION(rModel.initialTime() < rExerciseTimes.front());
  PRECONDITION(std::is_sorted(rExerciseTimes.begin(), rExerciseTimes.end(),
                              std::less_equal<double>()));

  std::vector<double> uEventTimes(rExerciseTimes.size() + 1);
  uEventTimes.front() = rModel.initialTime();
  copy(rExerciseTimes.begin(), rExerciseTimes.end(), uEventTimes.begin() + 1);
  rModel.assignEventTimes(uEventTimes);

  int iTime = uEventTimes.size() - 1;
  Slice uOption = rModel.cash(iTime, 0);
  while (iTime > 0)
  {
    //uOption is the value to continue
    uOption = max(swap(iTime, rSwap, rModel), uOption);
    iTime--;
    uOption.rollback(iTime);
  }
  return interpolate(uOption);
}
