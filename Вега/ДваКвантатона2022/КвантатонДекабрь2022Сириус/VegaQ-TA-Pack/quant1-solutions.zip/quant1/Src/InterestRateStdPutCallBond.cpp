#include "quant1/quant1.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    putCallBond(const Data::CashFlow &rBond,
                double dRedemptionPrice, double dRepurchasePrice,
                InterestRateModel &rModel)
{
  PRECONDITION(rBond.numberOfPayments > 0);

  std::vector<double> uEventTimes(rBond.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rBond](double dX)
                 { return dX + rBond.period; });
  rModel.assignEventTimes(uEventTimes);

  int iTime = uEventTimes.size() - 1; //last minus one coupon time
  double dCoupon = rBond.rate * rBond.period;
  Slice uDiscount =
      rModel.discount(iTime, rModel.eventTimes()[iTime] + rBond.period);
  Slice uBond = uDiscount * (1. + dCoupon);

  while (iTime > 0)
  {
    //uBond is the value to continue
    uBond = min(uBond, dRepurchasePrice);
    uBond = max(uBond, dRedemptionPrice);
    uBond += dCoupon;
    iTime--;
    uBond.rollback(iTime);
  }

  uBond *= rBond.notional;
  return interpolate(uBond);
}
