#include "quant1/quant1.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    forwardSwapLock(const Data::Swap &rSwap, double dMaturity,
                    InterestRateModel &rModel)
{
  PRECONDITION(rModel.initialTime() < dMaturity);

  std::vector<double> uEventTimes(1, rModel.initialTime());
  rModel.assignEventTimes(uEventTimes);

  int iTime = 0;
  // the value of float payments (we multiply on notional at the end)
  Slice uOption = rModel.discount(iTime, dMaturity);

  double dPaymentTime = dMaturity;
  double dFixedCoupon = rSwap.rate * rSwap.period;

  for (unsigned iI = 0; iI < rSwap.numberOfPayments; iI++)
  {
    dPaymentTime += rSwap.period;
    uOption -= rModel.discount(iTime, dPaymentTime) * dFixedCoupon;
  }
  uOption -= rModel.discount(iTime, dPaymentTime);

  if (rSwap.payFloat)
  {
    uOption *= (-1.);
  }
  uOption *= rSwap.notional;

  return interpolate(uOption);
}
