#include "quant1/quant1.hpp"

using namespace cfl;
using namespace std;

cfl::Slice
couponBond(unsigned iTime, const Data::CashFlow &rBond,
           const InterestRateModel &rModel)
{
  Slice uCashFlow = rModel.cash(iTime, 0.);
  double dTime = rModel.eventTimes()[iTime];
  for (unsigned iI = 0; iI < rBond.numberOfPayments; iI++)
  {
    dTime += rBond.period;
    uCashFlow += rModel.discount(iTime, dTime);
  }
  uCashFlow *= (rBond.rate * rBond.period);
  uCashFlow += rModel.discount(iTime, dTime);
  uCashFlow *= rBond.notional;
  return uCashFlow;
}

cfl::MultiFunction prb::
    futuresOnCheapToDeliver(double dFuturesMaturity,
                            unsigned iFuturesTimes,
                            const std::vector<cfl::Data::CashFlow> &rBonds,
                            InterestRateModel &rModel)
{
  double dPeriod = (dFuturesMaturity - rModel.initialTime()) / (iFuturesTimes);
  std::vector<double> uEventTimes(iFuturesTimes + 1);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [dPeriod](double dX)
                 { return dX + dPeriod; });
  rModel.assignEventTimes(uEventTimes);

  int iTime = rModel.eventTimes().size() - 1;
  //select the cheapest to deliver
  Slice uBond = rModel.cash(iTime, std::numeric_limits<double>::max());
  for (unsigned iI = 0; iI < rBonds.size(); iI++)
  {
    uBond = min(uBond, couponBond(iTime, rBonds[iI], rModel));
  }
  //future price at maturity
  Slice uFutures = uBond;
  while (iTime > 0)
  {
    //uFutures is the future price today
    iTime--;
    uFutures.rollback(iTime);
    uFutures /= rModel.discount(iTime, rModel.eventTimes()[iTime] + dPeriod);
  }
  return interpolate(uFutures);
}
