#include "quant1/quant1.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    americanPutOnFRA(double dFixedRate, double dPeriod, double dNotional,
                     const std::vector<double> &rExerciseTimes,
                     InterestRateModel &rModel)
{
  PRECONDITION(rModel.initialTime() < rExerciseTimes.front());
  PRECONDITION(std::is_sorted(rExerciseTimes.begin(), rExerciseTimes.end(),
                              std::less_equal<double>()));

  std::vector<double> uEventTimes(rExerciseTimes.size() + 1);
  uEventTimes.front() = rModel.initialTime();
  copy(rExerciseTimes.begin(), rExerciseTimes.end(), uEventTimes.begin() + 1);
  rModel.assignEventTimes(uEventTimes);

  int iTime = uEventTimes.size() - 1;
  Slice uOption = rModel.cash(iTime, 0.);
  double dFixedPayment = dNotional * (1. + dFixedRate * dPeriod);
  while (iTime > 0)
  {
    //uOption is the value to continue (no exercise before and now)
    double dTime = rModel.eventTimes()[iTime] + dPeriod;
    uOption =
        max(dNotional - rModel.discount(iTime, dTime) * dFixedPayment, uOption);
    iTime--;
    uOption.rollback(iTime);
  }
  return interpolate(uOption);
}
