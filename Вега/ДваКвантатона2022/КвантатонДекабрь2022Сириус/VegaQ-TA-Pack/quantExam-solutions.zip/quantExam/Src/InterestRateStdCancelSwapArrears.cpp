#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::Slice
floatInterest(unsigned iTime, double dPeriod, cfl::InterestRateModel &rModel)
{
  double dMaturity = rModel.eventTimes()[iTime] + dPeriod;
  return (1. / rModel.discount(iTime, dMaturity) - 1.);
}

cfl::MultiFunction prb::
    cancelSwapArrears(const cfl::Data::Swap &rSwap,
                      cfl::InterestRateModel &rModel)
{
  std::vector<double> uEventTimes(rSwap.numberOfPayments + 1);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rSwap](double dX)
                 { return dX + rSwap.period; });
  rModel.assignEventTimes(uEventTimes);

  int iTime = uEventTimes.size() - 1;
  Slice uOption = rModel.cash(iTime, 0.);
  double dFixedPayment = rSwap.rate * rSwap.period;
  while (iTime > 0)
  {
    // uOption is the value to continue
    // we multiply on notional at the end
    uOption = max(uOption, 0.);
    Slice uCurrentPayment =
        floatInterest(iTime, rSwap.period, rModel) - dFixedPayment;
    if (rSwap.payFloat)
    {
      uCurrentPayment *= -1.;
    }
    uOption += uCurrentPayment;
    iTime--;
    uOption.rollback(iTime);
  }
  uOption *= rSwap.notional;
  return interpolate(uOption);
}
