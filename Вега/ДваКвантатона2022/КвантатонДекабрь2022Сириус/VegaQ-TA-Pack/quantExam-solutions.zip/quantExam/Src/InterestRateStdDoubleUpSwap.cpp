#include "quantExam/quantExam.hpp"
using namespace std;
using namespace cfl;

cfl::Slice couponBond(unsigned iTime, const cfl::Data::CashFlow &rBond,
                      const InterestRateModel &rModel)
{
  cfl::Slice uCashFlow = rModel.cash(iTime, 0.);
  double dTime = rModel.eventTimes()[iTime];
  for (unsigned iI = 0; iI < rBond.numberOfPayments; iI++)
  {
    dTime += rBond.period;
    uCashFlow += rModel.discount(iTime, dTime);
  }
  uCashFlow *= (rBond.rate * rBond.period);
  uCashFlow += rModel.discount(iTime, dTime);
  uCashFlow *= rBond.notional;
  return uCashFlow;
}

cfl::Slice swap(unsigned iTime, const cfl::Data::Swap &rSwap,
                const InterestRateModel &rModel)
{
  // assume first that we receive fixed and pay float
  cfl::Slice uSwap = couponBond(iTime, rSwap, rModel) - rSwap.notional;
  if (!rSwap.payFloat)
  { // if we pay fixed
    uSwap *= -1;
  }
  return uSwap;
}

cfl::MultiFunction prb::
    doubleUpSwap(double dLowerBarrier, const cfl::Data::Swap &rSwap,
                 cfl::InterestRateModel &rModel)
{

  // event times: initial times plus payment times except the last
  std::vector<double> uEventTimes(rSwap.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rSwap](double dX)
                 { return dX + rSwap.period; });
  rModel.assignEventTimes(uEventTimes);

  // last minus one payment time
  int iTime = uEventTimes.size() - 1;
  // express barrier event in terms of discount factors
  double dUpperDiscount = 1. / (1. + dLowerBarrier * rSwap.period);
  cfl::Data::Swap uSwap(rSwap);
  uSwap.numberOfPayments = 1;

  Slice uBeforeBarrier = rModel.cash(iTime, 0.);
  Slice uAfterBarrier = rModel.cash(iTime, 0.);
  Slice uDiscount;
  double dNextTime;

  while (iTime > 0)
  {
    // uBeforeBarrier is the value of additional payments if no
    // barriers have been crossed before and now.
    // uAfterBarrier is the value of additional payments after the
    // barriers have been crossed but we have not exercised before and
    // now.
    dNextTime = rModel.eventTimes()[iTime] + rSwap.period;
    uDiscount = rModel.discount(iTime, dNextTime);
    uAfterBarrier = max(uAfterBarrier, swap(iTime, uSwap, rModel));
    uBeforeBarrier +=
        (uAfterBarrier - uBeforeBarrier) * indicator(uDiscount, dUpperDiscount);
    iTime--;
    uAfterBarrier.rollback(iTime);
    uBeforeBarrier.rollback(iTime);
    uSwap.numberOfPayments += 1;
  }
  ASSERT(uSwap.numberOfPayments == rSwap.numberOfPayments);
  uBeforeBarrier += swap(iTime, uSwap, rModel);

  return interpolate(uBeforeBarrier);
}
