#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    americanPutOnFutures(double dNotional, double dBondMaturity,
                         double dFuturesMaturity, unsigned iFuturesTimes,
                         double dStrike, InterestRateModel &rModel)
{
  PRECONDITION(dBondMaturity > dFuturesMaturity);

  double dPeriod = (dFuturesMaturity - rModel.initialTime()) / (iFuturesTimes);
  std::vector<double> uEventTimes(iFuturesTimes + 1);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [dPeriod](double dX)
                 { return dX + dPeriod; });
  ASSERT(std::abs(uEventTimes.back() - dFuturesMaturity) < cfl::EPS);
  rModel.assignEventTimes(uEventTimes);

  int iTime = rModel.eventTimes().size() - 1;
  Slice uFutures = dNotional * rModel.discount(iTime, dBondMaturity);
  Slice uPut = rModel.cash(iTime, 0.);
  while (iTime > 0)
  {
    // uPut is value to continue
    uPut = max(uPut, dStrike - uFutures);
    iTime--;
    uFutures.rollback(iTime);
    uFutures /= rModel.discount(iTime, rModel.eventTimes()[iTime] + dPeriod);
    uPut.rollback(iTime);
  }

  return interpolate(uPut);
}
