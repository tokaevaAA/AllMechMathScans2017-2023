#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
upOutFloor(const Data::CashFlow &rFloor, double dUpperLiborBarrier,
	   InterestRateModel &rModel)
{
  std::vector<double> uEventTimes(rFloor.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rFloor](double dX) { return dX + rFloor.period; });
  rModel.assignEventTimes(uEventTimes);

  //last minus one payment time
  int iTime = uEventTimes.size() - 1;
  //express barrier event in terms of discount factors
  double dLowerDiscount = 1. / (1. + dUpperLiborBarrier * rFloor.period);
  //fixed payment plus notional (as percentage of notional)
  double dFixedFactor = 1. + rFloor.period * rFloor.rate;
  double dPaymentTime = rModel.eventTimes()[iTime] + rFloor.period;
  Slice uDiscount = rModel.discount(iTime, dPaymentTime);
  //value of next payment (we multiply on notional at the end)
  Slice uOption = max(uDiscount * dFixedFactor - 1., 0.);

  while (iTime > 0)
    {
      //uOption is the value to continue (the value of future payments
      //if no barriers have been crossed before and today).
      uOption *= indicator(uDiscount, dLowerDiscount);
      iTime--;
      uOption.rollback(iTime);
      dPaymentTime = rModel.eventTimes()[iTime] + rFloor.period;
      uDiscount = rModel.discount(iTime, dPaymentTime);
      //add value of next payment
      uOption += max(uDiscount * dFixedFactor - 1., 0.);
    }
  uOption *= rFloor.notional;

  return interpolate(uOption);
}
