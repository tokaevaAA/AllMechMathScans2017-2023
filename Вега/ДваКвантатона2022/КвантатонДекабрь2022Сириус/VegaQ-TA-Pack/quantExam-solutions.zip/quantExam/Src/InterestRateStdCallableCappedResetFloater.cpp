#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::Slice rate(unsigned iTime, double dPeriod, const InterestRateModel &rModel)
{
  PRECONDITION(iTime < rModel.eventTimes().size());
  PRECONDITION(dPeriod > cfl::EPS);
  double dTime = rModel.eventTimes()[iTime] + dPeriod;
  cfl::Slice uDiscount = rModel.discount(iTime, dTime);
  return (1. / uDiscount - 1.) / dPeriod;
}

// value of fixed coupons in percentage of notional
Slice fixedCoupons(const Slice &rCouponRate, double dPeriod,
                   unsigned iNumberOfPayments,
                   const InterestRateModel &rModel)
{
  unsigned iTime = rCouponRate.timeIndex();
  double dTime = rModel.eventTimes()[iTime];
  Slice uValueOfCoupons = rModel.cash(iTime, 0.);
  for (unsigned iI = 0; iI < iNumberOfPayments; iI++)
  {
    dTime += dPeriod;
    uValueOfCoupons += rModel.discount(iTime, dTime);
  }
  uValueOfCoupons *= rCouponRate;
  uValueOfCoupons *= dPeriod;
  return uValueOfCoupons;
}

cfl::MultiFunction prb::
    callableCappedResetFloater(const Data::CashFlow &rCap,
                               unsigned iCouponsBetweenResets,
                               double dLiborSpread,
                               double dInitialCouponRate,
                               double dRepaymentPrice,
                               InterestRateModel &rModel)
{
  unsigned iNumberOfResets = rCap.numberOfPayments / iCouponsBetweenResets - 1;
  ASSERT(iNumberOfResets >= 1);
  ASSERT(rCap.numberOfPayments == (iNumberOfResets + 1) * iCouponsBetweenResets);
  double dResetPeriod = rCap.period * iCouponsBetweenResets;
  // event times: initial time + all reset times
  std::vector<double> uEventTimes(iNumberOfResets + 1);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [dResetPeriod](double dX)
                 { return dX + dResetPeriod; });
  rModel.assignEventTimes(uEventTimes);

  // last minus one reset time
  int iTime = rModel.eventTimes().size() - 1;
  double dTime = rModel.eventTimes().back();
  Slice uCouponRate =
      min(rate(iTime, dResetPeriod, rModel) + dLiborSpread, rCap.rate);
  // uOption is the value to continue (includes next coupons and notional)
  Slice uOption = rModel.discount(iTime, dTime + dResetPeriod) +
                  fixedCoupons(uCouponRate, rCap.period, iCouponsBetweenResets, rModel);

  while (iTime > 0)
  {
    // uOption is the value to continue (includes the value of the next coupon).
    uOption = min(uOption, dRepaymentPrice);
    iTime--;
    uOption.rollback(iTime);
    if (iTime > 0)
    {
      uCouponRate =
          min(rate(iTime, dResetPeriod, rModel) + dLiborSpread, rCap.rate);
    }
    else
    {
      ASSERT(iTime == 0);
      uCouponRate = rModel.cash(iTime, dInitialCouponRate);
    }
    uOption +=
        fixedCoupons(uCouponRate, rCap.period, iCouponsBetweenResets, rModel);
  }
  uOption *= rCap.notional;
  return interpolate(uOption);
}
