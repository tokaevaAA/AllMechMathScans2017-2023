#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    resetCouponPutBond(const Data::CashFlow &rBond,
                       double dResetCouponRate, double dRedemptionPrice,
                       InterestRateModel &rModel)
{
  ASSERT(dRedemptionPrice < 1);
  ASSERT(dResetCouponRate < rBond.rate);
  ASSERT(rBond.numberOfPayments > 1);

  std::vector<double> uEventTimes(rBond.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rBond](double dX)
                 { return dX + rBond.period; });
  rModel.assignEventTimes(uEventTimes);

  // last minus one coupon time
  int iTime = uEventTimes.size() - 1;
  double dOriginalCoupon = rBond.notional * rBond.rate * rBond.period;
  double dResetCoupon = rBond.notional * dResetCouponRate * rBond.period;
  double dRedemptionValue = dRedemptionPrice * rBond.notional;
  Slice uDiscount =
      rModel.discount(iTime, rModel.eventTimes()[iTime] + rBond.period);
  Slice uBondBeforeReset = uDiscount * (rBond.notional + dOriginalCoupon);
  Slice uBondAfterReset = uDiscount * (rBond.notional + dResetCoupon);

  while (iTime > 0)
  {
    uBondAfterReset = max(uBondAfterReset, dRedemptionValue);
    uBondBeforeReset = min(uBondAfterReset, uBondBeforeReset);
    uBondAfterReset += dResetCoupon;
    uBondBeforeReset += dOriginalCoupon;
    iTime--;
    uBondBeforeReset.rollback(iTime);
    uBondAfterReset.rollback(iTime);
  }

  return interpolate(uBondBeforeReset);
}
