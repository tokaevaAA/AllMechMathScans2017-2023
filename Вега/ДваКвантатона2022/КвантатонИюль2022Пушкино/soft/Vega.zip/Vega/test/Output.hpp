#ifndef __test_all_Output_hpp__
#define __test_all_Output_hpp__

namespace test
{
#define OUTPUT_DIR "/home/kramkov/git/FC-IV/FC-Vega/Vega/build/output"
#define STUDENT_ID "Vega"
}

#endif // of __test_all_Output_hpp
