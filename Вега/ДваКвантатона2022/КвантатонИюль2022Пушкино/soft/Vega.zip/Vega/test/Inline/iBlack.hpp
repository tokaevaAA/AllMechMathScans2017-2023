//do not include this file
inline std::vector<double> test::Black::exerciseTimes()
{
  unsigned iExerciseTimes= 12;
  return test::getTimes(c_dInitialTime, c_dMaturity, iExerciseTimes);
}

inline std::vector<double> test::Black::barrierTimes()
{
  unsigned iBarrierTimes= 10;
  double dBarrierMaturity = c_dMaturity -0.1;
  return test::getTimes(c_dInitialTime, dBarrierMaturity, iBarrierTimes);
}

inline cfl::Data::Swap test::Black::swapParameters()
{
  cfl::Data::Swap uSwap;

  uSwap.notional = 1000.;
  uSwap.rate = 0.07; 
  uSwap.period = 0.25; 
  uSwap.numberOfPayments = 6; 
  uSwap.payFloat = true;
  return uSwap;
}

