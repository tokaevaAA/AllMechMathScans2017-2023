#include "cfl/AssetModel.hpp"

using namespace cfl;

//class AssetModel

cfl::AssetModel::AssetModel(IAssetModel *pNewModel)
    : m_pModel(pNewModel) {}
