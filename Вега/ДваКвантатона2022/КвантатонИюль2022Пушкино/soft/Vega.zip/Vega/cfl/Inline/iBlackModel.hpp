// do not include this file

inline cfl::AssetModel
cfl::Black::model(const Data &rData, double dInterval, double dQuality)
{
  return cfl::Black::model(rData, dInterval, brownian(dQuality));
}