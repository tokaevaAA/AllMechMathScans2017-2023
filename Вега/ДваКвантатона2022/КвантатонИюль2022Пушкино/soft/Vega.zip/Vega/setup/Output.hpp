#ifndef __setup_Output_hpp__
#define __setup_Output_hpp__

#include "test/Output.hpp"

namespace test
{
#define PROJECT_NAME "setup"
} // namespace test

#endif // of __setup_Output_hpp
