#ifndef __Exercises_hpp__
#define __Exercises_hpp__

/**
 * @file Exercises.hpp
 * @author Dmitry Kramkov (kramkov@andrew.cmu.edu)
 * @brief Exercises for "Financial Derivatives with C++".
 * @version 1.0
 * @date 2022-06-16
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "cfl/Data.hpp"
#include "cfl/AssetModel.hpp"

/**
 * @mainpage Exercises for "Financial Derivatives with C++"
 */

namespace prb
{
  /**
   * @defgroup cflAssetOptions Options on a single stock.
   *
   * This module deals with valuation of options on a single stock.
   * @{
   */

  /**
   * Computes the value of the <strong>European straddle
   * option</strong>.  In this contract, at maturity \p dMaturity a
   * holder of the option can either buy or sell the stock at strike
   * \p dStrike. In other words, the straddle option equals the sum of
   * the European put and call options with the same strike and
   * maturity.
   *
   * @param dStrike The strike of the option.
   * @param dMaturity The maturity of the option.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction straddle(double dStrike, double dMaturity,
                              cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>"corridor" option</strong>.
   * The last barrier time is the maturity of the option.  The payoff of
   * the option at maturity equals the product of the notional on the
   * percentage of the barrier times, when the price of the stock is less
   * than the upper barrier and is greater than the lower barrier.
   *
   * @param dNotional The notional amount.
   * @param dLowerBarrier The lower barrier.
   * @param dUpperBarrier The upper barrier.
   * @param rBarrierTimes The vector of barrier times. The first
   * time is greater than the initial time.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  corridor(double dNotional, double dLowerBarrier,
           double dUpperBarrier,
           const std::vector<double> &rBarrierTimes,
           cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>American butterfly
   * option</strong>.  In this contract, at any exercise time (from \p
   * rExerciseTimes) a holder of the option has the right to get the
   * following payoffs:
   *
   * 1. the long call with strike \p dStrike-dStrikeStep,
   * 2. the two short calls with strike \p dStrike,
   * 3. the long call with strike \p dStrike+dStrikeStep.
   *
   * After such an exercise, the option is terminated.
   *
   * @param dStrike The strike in the middle.
   * @param dStrikeStep The length of the wing.
   * @param rExerciseTimes The vector of exercise times. The first exercise
   * time is strictly greater than the initial time.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  americanButterfly(double dStrike, double dStrikeStep,
                    const std::vector<double> &rExerciseTimes,
                    cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>down-and-rebate
   * option</strong>. The option pays notional \p dNotional at the
   * first barrier time when the spot price is below lower barrier \p
   * dLowerBarrier. Otherwise, the option expires worthless.
   *
   * @param dLowerBarrier The lower barrier.
   * @param dNotional The notional amount.
   * @param rBarrierTimes The vector of barrier times. The first
   * time is greater than the initial time.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  downRebate(double dLowerBarrier, double dNotional,
             const std::vector<double> &rBarrierTimes,
             cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>up-and-in American
   * put</strong>.  The option becomes American put with strike \p
   * dStrike and exercise times \p rExerciseTimes after the first
   * barrier time when the stock price is above barrier \p
   * dBarrier. If the price of the stock stays below \p dBarrier for
   * all barrier times, then the option expires worthless.
   *
   * @param dBarrier The upper barrier.
   * @param rBarrierTimes The vector of barrier times. The first
   * time is greater than the initial time.
   * @param dStrike The strike of the option.
   * @param rExerciseTimes The vector of exercise times. The first exercise
   * time is strictly greater than the initial time.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  upInAmericanPut(double dBarrier,
                  const std::vector<double> &rBarrierTimes,
                  double dStrike,
                  const std::vector<double> &rExerciseTimes,
                  cfl::AssetModel &rModel);

  /**
   * Computes the value of foreign exchange cancellable swap. In this
   * contract, at initial time we pay notional EUR (foreign currency) and
   * receive notional USD (domestic currency).  Later at payment times we
   * pay fixed rate USD and receive float plus spread EUR.  At payment
   * times we have the right to terminate swap. In this case, the last
   * transaction takes place at the next payment time and consists of
   * interest payments and notional amounts. In single asset model the
   * forward curve defines the forward exchange rate, where exchange rate
   * is the number of units of domestic currency needed to buy one unit of
   * foreign currency.
   *
   * @param dDomesticNotional The notional amount in domestic currency.
   * @param dFixedRate The fixed rate in the swap (domestic currency).
   * @param dForeignNotional The notional amount in foreign currency.
   * @param dFloatSpread The spread for float (foreign) rate.
   * @param dPeriod The time interval between two payments
   * (as year fraction).
   * @param iNumberOfPayments The number of payments.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  fxCancellableSwap(double dDomesticNotional,
                    double dFixedRate,
                    double dForeignNotional,
                    double dFloatSpread,
                    double dPeriod, unsigned iNumberOfPayments,
                    cfl::AssetModel &rModel);
  /** @} */
}

#endif // of __Exercises_hpp__
