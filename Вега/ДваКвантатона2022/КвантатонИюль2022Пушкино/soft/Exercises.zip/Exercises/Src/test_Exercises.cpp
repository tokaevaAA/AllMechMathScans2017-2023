#include "test/Main.hpp"
#include "test/Black.hpp"
#include "test/Print.hpp"
#include "Exercises/Output.hpp"
#include "Exercises/Exercises.hpp"

using namespace test;
using namespace cfl;
using namespace std;
using namespace test::Black;

MultiFunction straddle(AssetModel &rModel)
{
  test::print("EUROPEAN STRADDLE OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  double dMaturity = test::Black::c_dMaturity;

  print(dStrike, "strike");
  print(dMaturity, "maturity", true);

  return prb::straddle(dStrike, dMaturity, rModel);
}

MultiFunction corridor(AssetModel &rModel)
{
  test::print("CORRIDOR OPTION IN ASSET MODEL");

  double dNotional = test::Black::c_dNotional;
  double dLowerBarrier = test::Black::c_dSpot * 0.95;
  double dUpperBarrier = test::Black::c_dSpot * 1.1;
  const std::vector<double>
      uBarrierTimes = test::Black::exerciseTimes();

  print(dNotional, "notional");
  print(dLowerBarrier, "lower barrier");
  print(dUpperBarrier, "upper barrier", true);
  test::print(uBarrierTimes.begin(), uBarrierTimes.end(), "barrier times");

  return prb::corridor(dNotional, dLowerBarrier, dUpperBarrier,
                       uBarrierTimes, rModel);
}

MultiFunction americanButterfly(AssetModel &rModel)
{
  test::print("AMERICAN BUTTERFLY OPTION IN ASSET MODEL");
  double dStrike = test::Black::c_dSpot;
  double dStrikeStep = dStrike * 0.05;
  const std::vector<double> uExerciseTimes = test::Black::exerciseTimes();

  print(dStrike, "strike");
  print(dStrikeStep, "strike step", true);
  test::print(uExerciseTimes.begin(), uExerciseTimes.end(), "exercise times");

  return prb::americanButterfly(dStrike, dStrikeStep,
                                uExerciseTimes, rModel);
}

MultiFunction downRebate(AssetModel &rModel)
{
  test::print("DOWN-AND-REBATE OPTION IN ASSET MODEL");

  double dLowerBarrier = test::Black::c_dSpot * 0.9;
  double dNotional = test::Black::c_dNotional;
  const std::vector<double>
      uBarrierTimes = test::Black::barrierTimes();

  print(dLowerBarrier, "lower barrier");
  print(dNotional, "notional", true);
  test::print(uBarrierTimes.begin(), uBarrierTimes.end(), "barrier times");

  return prb::downRebate(dLowerBarrier,
                         dNotional, uBarrierTimes, rModel);
}

MultiFunction upInAmericanPut(AssetModel &rModel)
{
  test::print("UP-AND-IN AMERICAN PUT OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  const std::vector<double> uExerciseTimes = test::Black::exerciseTimes();
  double dUpperBarrier = test::Black::c_dSpot * 1.1;
  const std::vector<double> uBarrierTimes = test::Black::barrierTimes();

  print(dStrike, "strike");
  print(dUpperBarrier, "upper barrier", true);
  test::print(uExerciseTimes.begin(), uExerciseTimes.end(), "exercise times");
  test::print(uBarrierTimes.begin(), uBarrierTimes.end(), "barrier times");

  return prb::upInAmericanPut(dUpperBarrier, uBarrierTimes, dStrike,
                              uExerciseTimes, rModel);
}

MultiFunction fxCancellableSwap(AssetModel &rModel)
{
  test::print("FX CANCELLABLE SWAP IN ASSET MODEL");

  double dDomNotional = 10000;
  double dDomFixedRate = test::Black::c_dYield;
  double dForNotional = dDomNotional / atOrigin(rModel.spot(0));
  double dForLiborSpread = 0.005;
  double dPeriod = 0.25;
  unsigned iNumberOfPayments = 4;

  print(dDomNotional, "domestic notional");
  print(dDomFixedRate, "domestic fixed rate");
  print(dForNotional, "foreign notional");
  print(dForLiborSpread, "spread for foreign float rate");
  print(dPeriod, "period between payments");
  print(iNumberOfPayments, "number of payments", true);

  return prb::fxCancellableSwap(dDomNotional, dDomFixedRate,
                                dForNotional, dForLiborSpread,
                                dPeriod, iNumberOfPayments,
                                rModel);
}

std::function<void()> test_Exercises()
{
  return []()
  {
    print("OPTIONS ON A SINGLE STOCK IN BLACK MODEL");

    AssetModel uModel = test::Black::model();

    report(straddle, uModel);
    report(corridor, uModel);
    report(americanButterfly, uModel);
    report(downRebate, uModel);
    report(upInAmericanPut, uModel);
    report(fxCancellableSwap, uModel);
  };
}

int main()
{
  project(test_Exercises(), PROJECT_NAME, PROJECT_NAME,
          "Exercises");
}
