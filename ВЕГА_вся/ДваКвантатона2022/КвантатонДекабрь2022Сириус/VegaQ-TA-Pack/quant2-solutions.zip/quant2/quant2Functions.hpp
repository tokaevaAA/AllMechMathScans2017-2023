#ifndef __prbquant2Functions_hpp__
#define __prbquant2Functions_hpp__

/**
 * @file quant2Functions.hpp
 * @author Dmitry Kramkov (kramkov@andrew.cmu.edu)
 * @brief Auxiliary functions 
 * @version 1.0
 * @date 2022.10
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include "cfl/InterestRateModel.hpp"

namespace prb
{
  /** 
   * Computes the value of constant maturity swap. The float
   * payments here occur according to market swap rate for
   * \p iCMSPeriods. The model \p rModel needs to contain 
   * all CMS payment times except the last one.   
   * 
   * @param iEventTime The index of current event time. 
   * @param rSwap The parameters of the swap.
   * @param iCMSPeriods The number of periods used to determine float rate. 
   * @param rModel Reference to implementation of cfl::InterestRateModel.
   * 
   * @return The value of constant maturity swap at its issue time 
   * <code> rIndexesSetTimes.front()</code>.
   */
  cfl::Slice cms(unsigned iEventTime,
		 const cfl::Data::Swap &rSwap, unsigned iCMSPeriods,
		 const cfl::InterestRateModel &rModel);

  /** 
   * Computes swap rate. 
   * 
   * @param iTime The index of the current event time. 
   * @param dPeriod The time interval (given as year fraction) for
   * interest rate loan. 
   * @param iNumberOfPayments The number of payments in the swap contract.
   * @param rModel Reference to implementation of cfl::InterestRateModel.
   * 
   * @return The swap rate (the fixed rate that makes the value of
   * swap contract equaled to zero) at event time with index \p
   * iTime for the swap contract with number of payment \p
   * iNumberOfPayments and the interval between two payments \p
   * dPeriod. 
   */
  cfl::Slice swapRate(unsigned iTime, double dPeriod, unsigned iNumberOfPayments,
		      const cfl::InterestRateModel &rModel);
} // namespace prb

#endif // of __prbquant2Functions_hpp__
