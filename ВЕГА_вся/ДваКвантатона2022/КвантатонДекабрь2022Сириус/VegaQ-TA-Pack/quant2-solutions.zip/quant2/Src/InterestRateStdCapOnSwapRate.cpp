#include "quant2/quant2.hpp" 
#include "quant2/quant2Functions.hpp"

using namespace cfl;
using namespace std;

cfl::Slice prb::
swapRate(unsigned iTime, double dPeriod, 
	 unsigned iPeriods, const cfl::InterestRateModel & rModel) 
{
  cfl::Slice uFixed = rModel.cash(iTime, 0.);
  double dTime = rModel.eventTimes()[iTime];
  for (unsigned iI=0; iI<iPeriods; iI++) {
    dTime += dPeriod;
    uFixed += rModel.discount(iTime, dTime);
  }
  uFixed *= dPeriod;
  cfl::Slice uFloat = 1. - rModel.discount(iTime, dTime);
  cfl::Slice uRate= (uFloat/uFixed);
  return uRate;	
}


cfl::MultiFunction prb::
capOnSwapRate(const Data::CashFlow & rCap, 
	      double dSwapPeriod, unsigned iSwapPayments,
	      InterestRateModel & rModel)
{
  //event times: initial time + payment times - maturity
  std::vector<double> uEventTimes(rCap.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end()-1, 
		 uEventTimes.begin()+1, 
		 [&rCap](double dX){ return dX+rCap.period; }); 
  rModel.assignEventTimes(uEventTimes);

  //last minus one payment time  
  int iTime = uEventTimes.size()-1;
  Slice uDiscount = 
    rModel.discount(iTime, rModel.eventTimes()[iTime]+rCap.period);
  Slice uOption = uDiscount 
    * max(swapRate(iTime, dSwapPeriod, iSwapPayments, rModel)-rCap.rate,0.);

  while (iTime > 0) {
    //uOption is the value of future payments
    //we multiply on rCap.notional*rCap.period at the end
    iTime--;
    uOption.rollback(iTime);
    uDiscount = rModel.discount(iTime, rModel.eventTimes()[iTime]+rCap.period);
    uOption += uDiscount 
      * max(swapRate(iTime, dSwapPeriod, iSwapPayments, rModel)-rCap.rate,0.);
  }
  uOption *= (rCap.notional*rCap.period);

  return interpolate(uOption);	
}
