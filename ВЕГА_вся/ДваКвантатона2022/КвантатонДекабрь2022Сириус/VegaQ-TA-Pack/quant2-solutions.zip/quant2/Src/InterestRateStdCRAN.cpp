#include "quant2/quant2.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    callableRangeAccruedNote(const Data::CashFlow &rNote,
                             unsigned iNumberOfLookupDates,
                             double dLowerBarrier,
                             double dUpperBarrier,
                             double dLiborPeriod,
                             InterestRateModel &rModel)
{
  PRECONDITION(dLowerBarrier < dUpperBarrier);

  unsigned iEventTimes = rNote.numberOfPayments * (iNumberOfLookupDates + 1);
  std::vector<double> uEventTimes(iEventTimes, rModel.initialTime());
  double dLookupPeriod = rNote.period / (1. + iNumberOfLookupDates);
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [dLookupPeriod](double dX)
                 { return dX + dLookupPeriod; });
  rModel.assignEventTimes(uEventTimes);

  double dLowerDiscountBarrier = 1. / (1. + dUpperBarrier * dLiborPeriod);
  double dUpperDiscountBarrier = 1. / (1 + dLowerBarrier * dLiborPeriod);
  double dAccruedCoupon = rNote.rate * rNote.period / iNumberOfLookupDates;

  // last lookup time. We multiply on notional at the end.
  unsigned int iTime = uEventTimes.size() - 1;
  double dNextCouponTime = uEventTimes.back() + rNote.period / (iNumberOfLookupDates + 1);
  unsigned iPrevCouponTime = iTime - iNumberOfLookupDates;
  Slice uNote = rModel.discount(iTime, dNextCouponTime);
  Slice uBarrierDiscount, uInd;
  while (iTime > 0)
  {
    // uNote is the value to continue (the value of all future
    // accrued coupons and notional if there is no exercise today and in the past)

    // 2 possibilities: iTime is coupon time or lookup time
    if (iTime == iPrevCouponTime)
    {
      // coupon time: check on exercise
      dNextCouponTime = rModel.eventTimes()[iTime];
      iPrevCouponTime -= (iNumberOfLookupDates + 1);
      uNote = min(uNote, 1.);
    }
    else
    {
      ASSERT(iPrevCouponTime < iTime);
      ASSERT(rModel.eventTimes()[iTime] < dNextCouponTime);
      // lookup time: add current accrued coupon
      double dLiborMaturity = rModel.eventTimes()[iTime] + dLiborPeriod;
      uBarrierDiscount = rModel.discount(iTime, dLiborMaturity);
      uInd = indicator(uBarrierDiscount, dLowerDiscountBarrier) * indicator(dUpperDiscountBarrier, uBarrierDiscount);
      uNote += dAccruedCoupon * uInd * rModel.discount(iTime, dNextCouponTime);
    }
    iTime--;
    uNote.rollback(iTime);
  }
  uNote *= rNote.notional;
  return interpolate(uNote);
}
