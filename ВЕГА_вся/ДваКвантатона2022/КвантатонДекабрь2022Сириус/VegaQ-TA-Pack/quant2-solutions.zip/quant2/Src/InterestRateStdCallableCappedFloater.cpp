#include "quant2/quant2.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::
    callableCappedFloater(const Data::CashFlow &rCap, double dLiborSpread,
                          InterestRateModel &rModel)
{
    // all payment time except the last one
    std::vector<double> uEventTimes(rCap.numberOfPayments);
    uEventTimes.front() = rModel.initialTime();
    std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                   uEventTimes.begin() + 1,
                   [&rCap](double dX)
                   { return dX + rCap.period; });
    rModel.assignEventTimes(uEventTimes);

    // last minus one payment time
    int iTime = rModel.eventTimes().size() - 1;
    Slice uDiscount =
        rModel.discount(iTime, rModel.eventTimes()[iTime] + rCap.period);
    double dSpreadFactor = dLiborSpread * rCap.period - 1.;
    double dCapFactor = rCap.rate * rCap.period;
    Slice uValueOfNextCoupon =
        min(1. + dSpreadFactor * uDiscount, dCapFactor * uDiscount);
    // uOption is the value to continue (includes next coupon)
    Slice uOption = uDiscount + uValueOfNextCoupon;

    while (iTime > 0)
    {
        // uOption is the value to continue (includes the value of the next coupon).
        uOption = min(uOption, 1.);
        iTime--;
        uOption.rollback(iTime);
        uDiscount =
            rModel.discount(iTime, rModel.eventTimes()[iTime] + rCap.period);
        uValueOfNextCoupon =
            min(1. + dSpreadFactor * uDiscount, dCapFactor * uDiscount);
        uOption += uValueOfNextCoupon;
    }

    uOption *= rCap.notional;
    return interpolate(uOption);
}
