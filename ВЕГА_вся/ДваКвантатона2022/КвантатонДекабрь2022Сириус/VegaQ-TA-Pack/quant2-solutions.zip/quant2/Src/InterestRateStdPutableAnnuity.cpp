#include "quant2/quant2.hpp"

using namespace cfl;
using namespace std;

double annuityRatio(double dPeriod, int iNumberOfPayments,
                    double dAnnuityRate)
{
  PRECONDITION(dPeriod > 0);
  PRECONDITION(dAnnuityRate >= 0);
  PRECONDITION(iNumberOfPayments > 0);

  double dFactor = 1. / (1. + dAnnuityRate * dPeriod);
  if (std::abs(1. - dFactor) < cfl::EPS)
  {
    return iNumberOfPayments;
  }
  else
  {
    return dFactor * (1. - std::pow(dFactor, iNumberOfPayments)) / (1. - dFactor);
  }
}

cfl::MultiFunction prb::
    putableAnnuity(const Data::CashFlow &rAnnuity,
                   InterestRateModel &rModel)
{
  // event times: initial time + payment times except the last one
  std::vector<double> uEventTimes(rAnnuity.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::transform(uEventTimes.begin(), uEventTimes.end() - 1,
                 uEventTimes.begin() + 1,
                 [&rAnnuity](double dX)
                 { return dX + rAnnuity.period; });
  rModel.assignEventTimes(uEventTimes);

  // last minus one payment time
  int iTime = uEventTimes.size() - 1;
  Slice uDiscount =
      rModel.discount(iTime, rModel.eventTimes()[iTime] + rAnnuity.period);
  // we multiply on face value at the end
  double dAnnuityPayment =
      1. / annuityRatio(rAnnuity.period, rAnnuity.numberOfPayments, rAnnuity.rate);
  // value of the next payment
  Slice uAnnuity = uDiscount * dAnnuityPayment;

  ASSERT(rAnnuity.numberOfPayments - iTime == 1);
  while (iTime > 0)
  {
    // uAnnuity is the value of future payments
    // remaining number of periods
    int iNumberOfPeriods = rAnnuity.numberOfPayments - iTime;
    // remaining notional (in percentage to face value)
    double dNotional = dAnnuityPayment *
                       annuityRatio(rAnnuity.period, iNumberOfPeriods, rAnnuity.rate);
    uAnnuity = min(uAnnuity, dNotional);
    uAnnuity += dAnnuityPayment;
    iTime--;
    uAnnuity.rollback(iTime);
  }
  uAnnuity *= rAnnuity.notional;

  return interpolate(uAnnuity);
}
