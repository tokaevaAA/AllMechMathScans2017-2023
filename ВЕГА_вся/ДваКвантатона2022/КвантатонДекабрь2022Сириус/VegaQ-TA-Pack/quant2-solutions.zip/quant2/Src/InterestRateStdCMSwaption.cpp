#include "quant2/quant2.hpp" 
#include "quant2/quant2Functions.hpp"

using namespace cfl;
using namespace std;
using namespace prb;

cfl::Slice 
    couponBond(unsigned iTime, const Data::CashFlow &rBond,
               const InterestRateModel &rModel)
{
  Slice uCashFlow = rModel.cash(iTime, 0.);
  double dTime = rModel.eventTimes()[iTime];
  for (unsigned iI = 0; iI < rBond.numberOfPayments; iI++)
  {
    dTime += rBond.period;
    uCashFlow += rModel.discount(iTime, dTime);
  }
  uCashFlow *= (rBond.rate * rBond.period);
  uCashFlow += rModel.discount(iTime, dTime);
  uCashFlow *= rBond.notional;
  return uCashFlow;
}


cfl::Slice
cmsFloatNote(unsigned iEventTime, const cfl::Data::Swap &rSwap, unsigned iCMSPeriods,
		  const cfl::InterestRateModel &rModel)
{
  const std::vector<double> &rEventTimes = rModel.eventTimes();
  const std::vector<double>::const_iterator itA = rEventTimes.begin()+iEventTime;
  double dEventTime = rEventTimes[iEventTime];
  unsigned iCMSTime = rSwap.numberOfPayments-1;
  double dTime = dEventTime + iCMSTime * rSwap.period;
  unsigned iTime = std::lower_bound(itA, rEventTimes.end(), dTime-cfl::EPS) - rEventTimes.begin();
  ASSERT(std::abs(dTime - rEventTimes[iTime]) < cfl::EPS);
  Slice uDiscount = rModel.discount(iTime, rModel.eventTimes()[iTime] + rSwap.period);
  Slice uRate = swapRate(iTime, rSwap.period, iCMSPeriods, rModel);
  Slice uNote = uDiscount * (1. + uRate * rSwap.period);
  while (iCMSTime > 0)
    {
      iCMSTime--;
      dTime = dEventTime + iCMSTime*rSwap.period;
      iTime = std::lower_bound(itA, rEventTimes.end(), dTime-cfl::EPS) - rEventTimes.begin();
      ASSERT(std::abs(dTime - rEventTimes[iTime]) < cfl::EPS);
      uNote.rollback(iTime);
      uDiscount = rModel.discount(iTime, dTime + rSwap.period);
      uRate = swapRate(iTime, rSwap.period, iCMSPeriods, rModel);
      uNote += uDiscount * uRate * rSwap.period;
    }
  uNote *= rSwap.notional;
  return uNote;
}

cfl::Slice
prb::cms(unsigned iEventTime,
	 const cfl::Data::Swap &rSwap, unsigned iCMSPeriods,
	 const cfl::InterestRateModel &rModel)
{
  //assume first that we receive fixed and pay float
  Slice uSwap = couponBond(iEventTime, rSwap, rModel) -
    cmsFloatNote(iEventTime, rSwap, iCMSPeriods, rModel);
  if (!rSwap.payFloat)
    { //if we pay fixed
      uSwap *= -1;
    }
  return uSwap;
}

cfl::MultiFunction prb::
CMSwaption(const Data::Swap & rSwap, double dMaturity,
	   unsigned iCMSPeriods, InterestRateModel & rModel)
{
  PRECONDITION(rModel.initialTime() < dMaturity);
  PRECONDITION(iCMSPeriods > 0);

  //initial time + maturity + payment times in cms except the last  
  std::vector<double> uEventTimes(rSwap.numberOfPayments+1);
  uEventTimes.front() = rModel.initialTime();
  uEventTimes[1] = dMaturity;
  std::transform(uEventTimes.begin()+1,uEventTimes.end()-1,uEventTimes.begin()+2, 
		 [&rSwap](double dX){ return dX+rSwap.period; }); 
  rModel.assignEventTimes(uEventTimes);
  
  unsigned iEventTime = 1; //maturity
  Slice uCMSwaption = max(cms(iEventTime, rSwap, iCMSPeriods, rModel),0.);
  uCMSwaption.rollback(0);
  return interpolate(uCMSwaption);
}
