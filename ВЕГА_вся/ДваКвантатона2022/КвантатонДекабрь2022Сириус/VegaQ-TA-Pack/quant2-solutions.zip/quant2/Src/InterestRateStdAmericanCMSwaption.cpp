#include "quant2/quant2.hpp"
#include "quant2/quant2Functions.hpp"

using namespace cfl;
using namespace std;
using namespace prb;

cfl::MultiFunction prb::
americanCMSwaption(const Data::Swap &rSwap,
		   const std::vector<double> &rExerciseTimes,
		   unsigned iCMSPeriods,
		   InterestRateModel &rModel)
{
  PRECONDITION(iCMSPeriods > 0);
  PRECONDITION(rExerciseTimes.front() > rModel.initialTime());
  PRECONDITION(std::is_sorted(rExerciseTimes.begin(), rExerciseTimes.end(),
                              std::less_equal<double>()));

  //event times = initial time + all cms set times
  std::vector<double> uEventTimes(1 + rExerciseTimes.size() * rSwap.numberOfPayments);
  std::vector<double> uCMSTimes(rSwap.numberOfPayments);
  uEventTimes.front() = rModel.initialTime();
  std::vector<double>::iterator itBegin = uEventTimes.begin();
  std::vector<double>::iterator itEnd = uEventTimes.begin() + 1;

  for (unsigned iI = 0; iI < rExerciseTimes.size(); iI++)
    {
      std::vector<double> uTimes(itBegin + 1, itEnd);
      uCMSTimes.front() = rExerciseTimes[iI];
      std::transform(uCMSTimes.begin(), uCMSTimes.end() - 1, uCMSTimes.begin() + 1,
		     [&rSwap](double dT) {
		       return dT + rSwap.period;
		     });
      itEnd = std::set_union(uTimes.begin(), uTimes.end(), uCMSTimes.begin(),
			     uCMSTimes.end(), itBegin + 1);
      itBegin = std::lower_bound(itBegin+1, itEnd, uCMSTimes.front());
    }
  uEventTimes.resize(itEnd - uEventTimes.begin());
  ASSERT(std::is_sorted(uEventTimes.begin(), uEventTimes.end(), std::less_equal<double>()));
  rModel.assignEventTimes(uEventTimes);

  unsigned iExerciseTime = rExerciseTimes.size()- 1;
  double dExerciseTime = rExerciseTimes[iExerciseTime];
  unsigned iEventTime = std::lower_bound(uEventTimes.begin(), uEventTimes.end(), dExerciseTime) -
    uEventTimes.begin();
  Slice uOption = rModel.cash(iEventTime, 0.);

  while (iExerciseTime > 0)
    {
      uOption = max(uOption, cms(iEventTime, rSwap, iCMSPeriods, rModel));
      iExerciseTime--;
      dExerciseTime = rExerciseTimes[iExerciseTime];
      iEventTime = std::lower_bound(uEventTimes.begin(), uEventTimes.begin() + iEventTime, dExerciseTime) -
	uEventTimes.begin();
      uOption.rollback(iEventTime);
    }
  ASSERT(iEventTime == 1);
  uOption = max(uOption, cms(iEventTime, rSwap, iCMSPeriods, rModel));
  uOption.rollback(0);

  return interpolate(uOption);
}
