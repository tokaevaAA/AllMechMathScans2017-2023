Start with

(a) instructions-wsl-windows.pdf if you have Windows or Linux
(b) instructions-mac-homebrew.pdf if you have Mac

Then continue with

(c) instructions-projects-prep.pdf 
