#ifndef __Examples_hpp__
#define __Examples_hpp__

/**
 * @file Examples.hpp
 * @author Dmitry Kramkov (kramkov@andrew.cmu.edu)
 * @brief Examples for the course.
 * @version 1.0
 * @date 2022-06-16
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "cfl/Data.hpp"
#include "cfl/Interp.hpp"
#include "cfl/AssetModel.hpp"

/**
 * @mainpage Examples for "Financial Derivatives with C++"
 */

namespace prb
{
  /**
   * @defgroup cflAssetOptions Options on a single stock.
   *
   * This module deals with valuation of options on a single stock.
   * @{
   */

  /**
   * Computes the value of the <strong>European put option</strong>.
   * In this contract, at maturity \p dMaturity a holder of the option
   * can sell the stock at strike \p dStrike.
   *
   * @param dStrike The strike of the option.
   * @param dMaturity The maturity of the option.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction put(double dStrike, double dMaturity, cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>call on forward price</strong>.
   * In this contract, at maturity \p dCallMaturity the holder of the
   * option can pay strike \p dStrike for the cash amount given by the
   * forward price computed at \p dCallMaturity for delivery at \p
   * dForwardMaturity.
   *
   * @param dStrike The strike of the option.
   * @param dCallMaturity The maturity of the option. It is strictly greater
   * than the initial time.
   * @param dForwardMaturity The maturity of the forward contract. It is
   * is strictly greater than \p dCallMaturity.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  callOnForwardPrice(double dStrike, double dCallMaturity,
                     double dForwardMaturity,
                     cfl::AssetModel &rModel);

  /**
   * Computes the price of the <strong>clique option</strong>. The payoff
   * of the option at maturity \p dMaturity is given by:
   * \f[
   * V(T) = \frac1{N} \sum_{i=1}^N \max(S(t_i) - K, 0),
   * \f]
   * where the summation is done over the set of averaging times
   * \p rAverageTimes,  \f$S(t)\f$ is the stock price at \f$t\f$,
   * and \f$K\f$ is the strike \p dStrike.
   *
   * @param dMaturity The maturity of the option.
   * @param rAverageTimes The vector of averaging times. The last averaging
   * time is less than the maturity.
   * @param dStrike The strike.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction clique(double dMaturity,
                            const std::vector<double> &rAverageTimes,
                            double dStrike,
                            cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>American put option</strong>.
   * In this contract, at any exercise time (from \p rExerciseTimes) a
   * holder of the option can sell the stock at strike \p dStrike.
   *
   * @param dStrike The strike of the option.
   * @param rExerciseTimes The vector of exercise times. The first exercise
   * time is strictly greater than the initial time.
   * @param rModel The reference to the implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  americanPut(double dStrike,
              const std::vector<double> &rExerciseTimes,
              cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>American call on forward
   * </strong>.  In this contract, at any exercise time (from \p
   * rExerciseTimes) a holder of the option has the right to enter a
   * long position in the forward contract with forward price \p
   * dForwardPrice and time to maturity \p dTimeToMaturity.
   *
   * @param dForwardPrice The forward price.
   * @param dTimeToMaturity The time to maturity of forward contract.
   * @param rExerciseTimes The vector of exercise times. The first exercise
   * time is strictly greater than the initial time.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  americanCallOnForward(double dForwardPrice,
                        double dTimeToMaturity,
                        const std::vector<double> &rExerciseTimes,
                        cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>up-or-down-and-out barrier
   * option</strong>. The payoff of the option at maturity (last
   * barrier time) is notional amount \p dNotional if the stock price
   * has not crossed the lower and upper barriers for all barrier
   * times. Otherwise, the option expires worthless.
   *
   * @param dLowerBarrier The lower barrier.
   * @param dUpperBarrier The upper barrier.
   * @param dNotional The notional amount.
   * @param rBarrierTimes The vector of barrier times. The first
   * time is greater than the initial time. The last barrier time is
   * the maturity of the option.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  barrierUpDownOut(double dNotional, double dLowerBarrier,
                   double dUpperBarrier,
                   const std::vector<double> &rBarrierTimes,
                   cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>down-and-out American
   * call</strong>.  The option behaves as the American call option
   * with strike \p dStrike and exercise times \p rExerciseTimes until
   * the first barrier time when the stock price hits lower barrier \p
   * dBarrier. At this exit time the option is canceled.
   *
   * @param dBarrier The lower barrier (\p dBarrier < \p dStrike).
   * @param rBarrierTimes The vector of barrier times. The first
   * time is greater than the initial time.
   * @param dStrike The strike of the option.
   * @param rExerciseTimes The vector of exercise times. The first exercise
   * time is strictly greater than the initial time.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */
  cfl::MultiFunction
  downOutAmericanCall(double dBarrier,
                      const std::vector<double> &rBarrierTimes,
                      double dStrike,
                      const std::vector<double> &rExerciseTimes,
                      cfl::AssetModel &rModel);

  /**
   * Computes the value of the <strong>swing option</strong>.  The
   * holder can exercise the option \p iNumberOfExercises times.  At
   * each exercise time he can buy only one stock for strike \p
   * dStrike.
   *
   * @param dStrike The strike of the option.
   * @param rExerciseTimes The vector of exercise times.
   * @param iNumberOfExercises The maximal number of exercises.
   * @param rModel The reference to an implementation of cfl::AssetModel.
   *
   * @return The price of the option as the function of the initial
   * values of the state processes in the model.
   */

  cfl::MultiFunction swing(double dStrike,
                           const std::vector<double> &rExerciseTimes,
                           unsigned iNumberOfExercises, cfl::AssetModel &rModel);
  /** @} */
}

#endif // of __Examples_hpp__
