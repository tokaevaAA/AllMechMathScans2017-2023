#include "test/Main.hpp"
#include "test/Data.hpp"
#include "test/Print.hpp"
#include "test/Black.hpp"
#include "Examples/Output.hpp"
#include "Examples/Examples.hpp"

using namespace test;
using namespace cfl;
using namespace std;
using namespace test::Data;

// OPTIONS ON A SINGLE STOCK IN BLACK MODEL

MultiFunction put(AssetModel &rModel)
{
  test::print("EUROPEAN PUT OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  double dMaturity = test::Black::c_dMaturity;

  print(dStrike, "strike");
  print(dMaturity, "maturity", true);

  return prb::put(dStrike, dMaturity, rModel);
}

MultiFunction callOnForwardPrice(AssetModel &rModel)
{
  test::print("CALL ON FORWARD PRICE IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  double dCallMaturity = test::Black::c_dMaturity;
  double dForwardMaturity = dCallMaturity + 0.5;

  print(dStrike, "strike");
  print(dCallMaturity, "maturity of call");
  print(dForwardMaturity, "maturity of forward", true);

  return prb::callOnForwardPrice(dStrike, dCallMaturity,
                                 dForwardMaturity, rModel);
}

MultiFunction clique(AssetModel &rModel)
{
  test::print("CLIQUE OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  std::vector<double> uAverageTimes = test::Black::exerciseTimes();
  double dMaturity = uAverageTimes.back() + 5. / 256.; // one week later

  print(dStrike, "strike");
  print(dMaturity, "maturity", true);
  test::print(uAverageTimes.begin(), uAverageTimes.end(), "averaging times");

  return prb::clique(dMaturity, uAverageTimes, dStrike, rModel);
}

MultiFunction
americanCallOnForward(AssetModel &rModel)
{
  test::print("AMERICAN CALL ON FORWARD IN ASSET MODEL");

  double dForwardPrice = test::Black::c_dSpot;
  double dTimeToMaturity = 0.5;
  const std::vector<double> uExerciseTimes = test::Black::exerciseTimes();

  print(dForwardPrice, "forward price");
  print(dTimeToMaturity, "time to maturity", true);
  test::print(uExerciseTimes.begin(), uExerciseTimes.end(), "exercise times");

  return prb::americanCallOnForward(dForwardPrice, dTimeToMaturity,
                                    uExerciseTimes, rModel);
}

MultiFunction americanPut(AssetModel &rModel)
{
  test::print("AMERICAN PUT OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  const std::vector<double> uExerciseTimes = test::Black::exerciseTimes();

  print(dStrike, "strike", true);
  test::print(uExerciseTimes.begin(), uExerciseTimes.end(), "exercise times");

  return prb::americanPut(dStrike, uExerciseTimes, rModel);
}

MultiFunction barrierUpDownOut(AssetModel &rModel)
{
  test::print("BARRIER UP-OR-DOWN-AND-OUT OPTION IN ASSET MODEL");

  double dLowerBarrier = test::Black::c_dSpot * 0.9;
  double dUpperBarrier = test::Black::c_dSpot * 1.1;
  double dNotional = test::Black::c_dNotional;
  const std::vector<double> uBarrierTimes = test::Black::barrierTimes();

  print(dLowerBarrier, "lower barrier");
  print(dUpperBarrier, "upper barrier");
  print(dNotional, "notional", true);
  test::print(uBarrierTimes.begin(), uBarrierTimes.end(), "barrier times");

  return prb::barrierUpDownOut(dNotional, dLowerBarrier,
                               dUpperBarrier, uBarrierTimes,
                               rModel);
}

MultiFunction
downOutAmericanCall(AssetModel &rModel)
{
  test::print("DOWN-AND-OUT AMERICAN CALL OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  const std::vector<double>
      uExerciseTimes = test::Black::exerciseTimes();
  double dLowerBarrier = test::Black::c_dSpot * 0.9;
  const std::vector<double>
      uBarrierTimes = test::Black::barrierTimes();

  print(dStrike, "strike");
  print(dLowerBarrier, "lower barrier", true);
  test::print(uExerciseTimes.begin(), uExerciseTimes.end(), "exercise times");
  test::print(uBarrierTimes.begin(), uBarrierTimes.end(), "barrier times");

  return prb::downOutAmericanCall(dLowerBarrier,
                                  uBarrierTimes, dStrike,
                                  uExerciseTimes, rModel);
}

MultiFunction swing(AssetModel &rModel)
{
  test::print("SWING OPTION IN ASSET MODEL");

  double dStrike = test::Black::c_dSpot;
  const std::vector<double> uExerciseTimes = test::Black::exerciseTimes();
  unsigned iNumberOfExercises = uExerciseTimes.size() / 3;

  print(dStrike, "strike");
  print(iNumberOfExercises, "maximal number of exercises", true);
  test::print(uExerciseTimes.begin(), uExerciseTimes.end(), "exercise times");

  return prb::swing(dStrike, uExerciseTimes,
                    iNumberOfExercises, rModel);
}

std::function<void()> test_Examples()
{
  return []()
  {
    print("OPTIONS ON A SINGLE STOCK IN BLACK MODEL");

    AssetModel uBlack = test::Black::model();
    test::Black::report(put, uBlack);
    test::Black::report(callOnForwardPrice, uBlack);
    test::Black::report(clique, uBlack);
    test::Black::report(americanPut, uBlack);
    test::Black::report(americanCallOnForward, uBlack);
    test::Black::report(barrierUpDownOut, uBlack);
    test::Black::report(downOutAmericanCall, uBlack);
    test::Black::report(swing, uBlack);
  };
}

int main()
{
  project(test_Examples(), PROJECT_NAME, PROJECT_NAME,
          "Examples");
}
