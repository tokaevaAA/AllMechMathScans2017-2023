#include "Examples/Examples.hpp"

using namespace std;
using namespace cfl;

cfl::MultiFunction prb::
    clique(double dMaturity, const std::vector<double> &rAverageTimes,
           double dStrike, AssetModel &rModel)
{
  PRECONDITION(rAverageTimes.front() > rModel.initialTime());
  PRECONDITION(rAverageTimes.back() < dMaturity);

  std::vector<double> uEventTimes(rAverageTimes.size() + 1);
  uEventTimes.front() = rModel.initialTime();
  copy(rAverageTimes.begin(), rAverageTimes.end(), uEventTimes.begin() + 1);
  rModel.assignEventTimes(uEventTimes);

  // last average time
  int iTime = rModel.eventTimes().size() - 1;
  Slice uOption = rModel.cash(iTime, 0.);
  while (iTime > 0)
  {
    // uOption is the present value of all future calls.
    // We divide on the number of averaging times at the end
    uOption += max(rModel.spot(iTime) - dStrike, 0.) * rModel.discount(iTime, dMaturity);
    iTime--;
    uOption.rollback(iTime);
  }
  // not forgetting to divide on the number of averaging times
  uOption /= rAverageTimes.size();

  return interpolate(uOption);
}
