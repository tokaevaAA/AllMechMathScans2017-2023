#include "Examples/Examples.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction
prb::callOnForwardPrice(double dStrike, double dCallMaturity,
                        double dForwardMaturity, AssetModel &rModel)
{
  PRECONDITION(rModel.initialTime() < dCallMaturity);
  PRECONDITION(dCallMaturity < dForwardMaturity);

  std::vector<double> uEventTimes = {rModel.initialTime(), dCallMaturity};
  rModel.assignEventTimes(uEventTimes);

  int iEventTime = 1;
  Slice uOption = max(rModel.forward(iEventTime, dForwardMaturity) - dStrike, 0.);
  uOption.rollback(0);
  return interpolate(uOption);
}
