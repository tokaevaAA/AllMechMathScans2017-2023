#include "Examples/Examples.hpp"

using namespace cfl;
using namespace std;

Slice longForward(double dForwardPrice, double dTimeToMaturity,
                  unsigned iTime, const AssetModel &rModel)
{
  double dMaturity = rModel.eventTimes()[iTime] + dTimeToMaturity;
  Slice uForward = rModel.discount(iTime, dMaturity) * (rModel.forward(iTime, dMaturity) - dForwardPrice);
  return uForward;
}
cfl::MultiFunction prb::
    americanCallOnForward(double dForwardPrice,
                          double dTimeToMaturity,
                          const std::vector<double> &rExerciseTimes,
                          AssetModel &rModel)
{
  PRECONDITION(rModel.initialTime() < rExerciseTimes.front());
  PRECONDITION(std::is_sorted(rExerciseTimes.begin(), rExerciseTimes.end(),
                              std::less_equal<double>()));

  std::vector<double> uEventTimes(rExerciseTimes.size() + 1);
  uEventTimes.front() = rModel.initialTime();
  copy(rExerciseTimes.begin(), rExerciseTimes.end(), uEventTimes.begin() + 1);
  rModel.assignEventTimes(uEventTimes);

  int iTime = uEventTimes.size() - 1;
  Slice uOption = rModel.cash(iTime, 0.);
  while (iTime > 0)
  {
    // uOption is the value to continue
    uOption = max(uOption, longForward(dForwardPrice, dTimeToMaturity,
                                       iTime, rModel));
    iTime--;
    uOption.rollback(iTime);
  }
  return interpolate(uOption);
}
